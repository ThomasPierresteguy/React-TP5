import React, { useState } from "react";

function App() {

  const [numero, setNumero] = useState(0);

  function aumentar() {
    setNumero(numero + 1);
  }

  function disminuir() {
    setNumero(numero - 1);
  }

  return (
    <div>
      <p>Contador: {numero}</p>
      <button onClick={aumentar}>Aumentar</button>
      <button onClick={disminuir}>Disminuir</button>
    </div>
  );
}

export default App;